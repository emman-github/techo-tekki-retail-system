import { Component } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, retry } from 'rxjs/operators';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'login-form';
  username: any;
  password: any;

  constructor(private httpClient: HttpClient) { }

  login() {
  	const url = 'https://kbb-back-end.000webhostapp.com/index.php/Welcome/login';

  	let params = new FormData();  
    params.append('ma_username', this.username);
    params.append('ma_password', this.password);
 
  	this.httpClient.post(url, params).subscribe(response => {
  		console.log(response);
  	})
  }
}
